//#ifndef __USART_H__
//#define __USART_H__
//#include "stm32f10x.h"   
//#include <stdio.h>
//void Serial_Init(void);
//void Serial_SendByte(uint16_t Byte);
//void Serial_SendArray(uint8_t *Array,uint16_t Length);
//void Serial_SendString(char *String);
//void Serial_SendNumber(uint32_t Number,uint8_t Length);
//int fputc(int ch,FILE *F);

//uint8_t Serial_GetRxFlag(void);
//uint8_t  Serial_GetRxData(void);
//void USART1_IRQHandler(void);
//#endif

#ifndef __USART_H__
#define __USART_H__
#include "stm32f10x.h"   
#include <stdio.h>
extern uint8_t Serial_TxPacket[];
extern uint8_t Serial_RxPacket[];
void Serial_Init(void);
void Serial_SendByte(uint16_t Byte);
void Serial_SendArray(uint8_t *Array,uint16_t Length);
void Serial_SendString(char *String);
void Serial_SendNumber(uint32_t Number,uint8_t Length);
int fputc(int ch,FILE *F);

uint8_t Serial_GetRxFlag(void);
void Serial_SendPacket(void);

#endif

