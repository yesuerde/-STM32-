#include "stm32f10x.h"                  // Device header

void Smog_Init(void)		//������������ʼ������ΪB6
{
	GPIO_InitTypeDef GPIO_InitStructure;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE );
	
	GPIO_InitStructure.GPIO_Mode =GPIO_Mode_IPD;
	GPIO_InitStructure.GPIO_Pin =GPIO_Pin_6;
	GPIO_InitStructure.GPIO_Speed =GPIO_Speed_50MHz;
	
	GPIO_Init(GPIOB ,&GPIO_InitStructure);
}

uint8_t GetSmogSensor(void)
{
	return GPIO_ReadInputDataBit (GPIOB,GPIO_Pin_6);
}
