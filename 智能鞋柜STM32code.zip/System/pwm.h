#ifndef __PWM_H__
#define __PWM_H__

void Timer_Init(uint16_t total,uint16_t duty);

#endif
