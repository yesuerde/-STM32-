#include "stm32f10x.h"                  // Device header


void Timer_Init(uint16_t total,uint16_t duty)
{
	TIM_OCInitTypeDef TIM_OCInitStructure;	
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;		
	GPIO_InitTypeDef GPIO_InitStructure;	
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);	
	
	TIM_InternalClockConfig(TIM3);		//�����ڲ�ʱ��
	TIM_TimeBaseInitStructure.TIM_ClockDivision =TIM_CKD_DIV1;
	TIM_TimeBaseInitStructure.TIM_CounterMode =TIM_CounterMode_Up;
	TIM_TimeBaseInitStructure.TIM_Period =total;
	TIM_TimeBaseInitStructure.TIM_Prescaler =duty ;
	TIM_TimeBaseInit(TIM3,&TIM_TimeBaseInitStructure);//����ʱ����Ԫ
	
	TIM_OCInitStructure.TIM_OCMode =TIM_OCMode_PWM1;
	TIM_OCInitStructure.TIM_OutputState =TIM_OutputState_Enable ;
	TIM_OCInitStructure.TIM_Pulse =duty ;
	TIM_OCInitStructure.TIM_OCPolarity =TIM_OCPolarity_High ;
	
	TIM_OC4Init (TIM3,&TIM_OCInitStructure);
	
	TIM_OC4PreloadConfig(TIM3,TIM_OCPreload_Enable );
	TIM_ARRPreloadConfig (TIM3,ENABLE );
	
	TIM_Cmd (TIM3,ENABLE);
}
