#ifndef __SMOG_H__
#define __SMOG_H__


void Smog_Init(void);
uint8_t GetSmogdSensor(void);

#endif
