#ifndef __VENTILATE_H__
#define __VENTILATE_H__

#include "stm32f10x.h"
void ventilate_Init (void);
void ventilate_on(void);
void ventilate_off(void);

#endif
