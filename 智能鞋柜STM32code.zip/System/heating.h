#ifndef __HEATING_H__
#define __HEATING_H__

#include "stm32f10x.h"
void heating_Init (void);
void heating_on(void);
void heating_off(void);

#endif
