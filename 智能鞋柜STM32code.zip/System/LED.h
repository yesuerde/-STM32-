#ifndef __LED_H__
#define __LED_H__

#include "stm32f10x.h"
void LED_Init (void);
void LED_on(void);
void LED_off(void);

#endif
