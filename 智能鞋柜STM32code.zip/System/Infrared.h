#ifndef __INFRARED_H__
#define __INFRARED_H__

void Infrared_Init(void);
uint8_t GetInfraredSensor(void);

#endif
