#define BLINKER_WIFI
#include <SoftwareSerial.h>
#include <Blinker.h>
//GHL
char auth[] = "89c8ca36547d";
// 替换为你的Wi-Fi信息
char ssid[] = "AAAA";
char pswd[] = "12345678";



int a;  // 接收温度
int b;  // 接收湿度
int c;  // 接收的原始数据

int SetTem = 0;  // 设置的温度阈值
int SetHum = 0;  // 设置的湿度阈值
int Set = 0;     // 组合数据：前两位温度，后两位湿度

BlinkerNumber Hum("hum");     // 显示接收到的湿度
BlinkerNumber Tem("tem");     // 显示接收到的温度
BlinkerNumber Hums("hums");     // 显示接收到的湿度
BlinkerNumber Tems("tems");     // 显示接收到的温度
BlinkerSlider Slider1("sli-tem");  // 温度阈值滑块
BlinkerSlider Slider2("sli-hum");  // 湿度阈值滑块

// 自定义串口 (RX, TX)   # D6接TX D7接RX
SoftwareSerial MySerial(D6, D7);

String data1;  // 接收外部数据

// 接收外部数据的函数
String receive1() {   
  String data = "";
  while (MySerial.available()) {
    data += (char)MySerial.read();
    delay(2); // 等待更多数据到达
  }
  return data;
}

void sendPacketToSTM32(int temp, int hum) {
    // 数据包格式：0xFF [SetTem] [SetHum] 0xFE
    uint8_t packet[4];
    packet[0] = 0xFF;         // 包头
    packet[1] = temp & 0xFF;  // 温度阈值（1 字节）
    packet[2] = hum & 0xFF;   // 湿度阈值（1 字节）
    packet[3] = 0xFE;         // 包尾

    MySerial.write(packet, 4); // 发送 4 字节数据包
    Serial.print("Sent Packet to STM32: 0xFF ");
    Serial.print(temp, DEC);
    Serial.print(" ");
    Serial.print(hum, DEC);
    Serial.println(" 0xFE");
}
// 温度滑块回调函数
void slider1_callback(int32_t value) {
  SetTem = value;
  BLINKER_LOG("Temperature Slider value: ", value);
  Serial.print("Temperature Slider received: ");
  Serial.println(SetTem);
  Blinker.print("sli-tem", SetTem);  // 反馈到APP，使用唯一键名
  Tems.print(SetTem);
}

// 湿度滑块回调函数
void slider2_callback(int32_t value) {
  SetHum = value;
  BLINKER_LOG("Humidity Slider value: ", value);
  Serial.print("Humidity Slider received: ");
  Serial.println(SetHum);
  Blinker.print("sli-hum", SetHum);  // 反馈到APP，使用唯一键名
  Hums.print(SetHum);
}

void setup() {
  Serial.begin(115200);    // 调试串口初始化
  MySerial.begin(9600);    // 与STM32通信串口初始化
  BLINKER_DEBUG.stream(Serial);  // Blinker调试输出到串口
  // 初始化Blinker
  Blinker.begin(auth, ssid, pswd);

  Slider1.attach(slider1_callback);  // 绑定温度滑块回调
  Slider2.attach(slider2_callback);  // 绑定湿度滑块回调
}

void loop() {  
  // 接收并处理来自STM32的数据
  data1 = receive1();
  if (data1 != "")
  {
    Serial.println(data1);    // 打印接收到的数据
    c = data1.toInt();
    a = c / 100;              // 提取温度
    b = c % 100;              // 提取湿度
    Tem.print(a);             // 显示温度到APP
    Hum.print(b);             // 显示湿度到APP
    Tems.print(SetTem);
    Hums.print(SetHum);
  }    

  static unsigned long lastSendTime = 0;
    if (millis() - lastSendTime >= 1000) {  // 每1000ms发送一次
        sendPacketToSTM32(SetTem, SetHum);  // 发送温度和湿度数据包
        lastSendTime = millis();
    }
  Blinker.run();  // 运行Blinker
}